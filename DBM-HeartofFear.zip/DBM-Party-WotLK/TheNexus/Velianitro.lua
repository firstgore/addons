local mod = DBM:NewMod("Veli'anitro", "DBM-Party-WotLK", 8)
local L		= mod:GetLocalizedStrings()

mod:SetRevision(("$Revision: 4442 $"):sub(12, -3))
mod:SetCreatureID(90000)


mod:RegisterCombat("yell", L.Start)

mod:RegisterEvents(
	"SPELL_CAST_START",
	"SPELL_AURA_APPLIED",
	"SPELL_AURA_REMOVED",
	"SPELL_DAMAGE",
	"SPELL_AURA_REMOVED",
	"UNIT_HEALTH",
	"CHAT_MSG_MONSTER_YELL"
)

local warnStat		= mod:NewTargetAnnounce(38280, 3)
local timerStat		= mod:NewNextTimer(20, 38280)
local warnAgility	= mod:NewSpellAnnounce(54603, 2)
local warnSonic		= mod:NewSpellAnnounce(64422, 4)
local timerSonic	= mod:NewCastTimer(64422)
local timerNextSonic = mod:NewNextTimer(30, 64422)
local testTimer = mod:NewTimer(20, "Pew Pew Pew...")

local warnedFaza		= false

mod:AddBoolOption("SetIconOnMirroredTarget", true)

function mod:OnCombatStart()
	warnedFaza = false
end



function mod:SPELL_CAST_START(args)
	if args:IsSpellID(64422) then --Sonic 
		warnSonic:Show()
		timerSonic:Start()
		timerNextSonic:Start()

	end
end

function mod:SPELL_AURA_APPLIED(args)
	if args:IsSpellID(38280) and args:IsDestTypePlayer() then	-- Static
		warnStat:Show(args.destName)
		timerStat:Start(args.destName)
		self:SendWhisper(L.Stat, args.destName)
		if self.Options.SetIconOnMirroredTarget then 
			self:SetIcon(args.destName, 8, 8) 
		end 
	elseif args:IsSpellID(54603) then					-- Agility
		warnAgility:Show()
        elseif args:IsSpellID(54603) then					-- Agility
		warnAgility:Show()
	end
end


function mod:UNIT_HEALTH(uId)
	if uId == "target" and self:GetUnitCreatureId(uId) == 90000 and UnitHealth(uId) / UnitHealthMax(uId) <= 0.95 and not warnedFaza then
		
		testTimer:Start(20, "Pew Pew Pew...")
		
		testTimer:UpdateIcon("Interface\\Icons\\Spell_Nature_Starfall", "Pew Pew Pew...")
		
		warnedFaza = true
	end
end





			


