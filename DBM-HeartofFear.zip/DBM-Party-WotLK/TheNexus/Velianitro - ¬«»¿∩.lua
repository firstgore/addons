local mod = DBM:NewMod("Velianitro", "DBM-Party-WotLK", 8)
local L		= mod:GetLocalizedStrings()

mod:SetRevision(("$Revision: 2869 $"):sub(12, -3))
mod:SetCreatureID(90000)

mod:RegisterCombat("COMBAT")
mod:RegisterEvents(
"SPELL_AURA_APPLIED",
"SPELL_AURA_REMOVED"
)


local warnStat		= mod:NewTargetAnnounce(38280, 3)
local timerStat		= mod:NewTargetTimer(20, 38280)

mod:AddBoolOption("SetIconOnMirroredTarget", true)


function mod:SPELL_AURA_APPLIED(args)
	if args:IsSpellID(38280) and args:IsDestTypePlayer() then	-- Mirrored Soul
		warnStat:Show(args.destName)
		timerStat:Show(args.destName)
		SendChatMessage(L.Stat, "SAY")
 			
		if self.Options.SetIconOnMirroredTarget then 
			self:SetIcon(args.destName, 8, 8)
		end 
	end
end



function mod:SPELL_AURA_REMOVED(args)
 if args:IsSpellID(38280) then
		self:SendHiddenWhisper(DBM_SOLARIAN_SPECWARN_WRATH, target)
 end
end
