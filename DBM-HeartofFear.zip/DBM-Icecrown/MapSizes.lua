DBM:RegisterMapSize("IcecrownCitadel",
	1, 1355.47009278, 903.647033691,	-- The Lower Citadel
	2, 1067, 711.3336906438,			-- The Rampart of Skulls
	3, 195.46997071, 130.315002441,		-- Deathbringer's Rise
	4, 773.71008301, 515.81030273,		-- The Frost Queen's Lair
	5, 1148.73999024, 765.82006836,		-- The Upper Reaches
	6, 373.70996094, 249.12988281,		-- Royal Quarters
	7, 293.26000977, 195.507019042,		-- The Frozen Throne
	8, 247.92993165, 165.287994385		-- Frostmourne
)