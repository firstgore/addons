local Rage = DBM:NewBossMod("Rage", DBM_RAGE_NAME, DBM_RAGE_DESCRIPTION, DBM_MOUNT_HYJAL, DBM_HYJAL_TAB, 1);

Rage.Version	= "1.0";
Rage.Author		= "Copperfield";

Rage:SetCreatureID(17767)
Rage:RegisterCombat("yell", DBM_RAGE_YELL_PULL)
Rage:SetMinCombatTime(60)

Rage:AddOption("WarnIce", true, DBM_RAGE_OPTION_ICEBOLT);
Rage:AddOption("IceIcon", false, DBM_RAGE_OPTION_ICON);
Rage:AddOption("WarnDnD", true, DBM_RAGE_OPTION_DND);
Rage:AddOption("WarnDnDSoon", true, DBM_RAGE_OPTION_DND_SOON);

Rage:AddBarOption("Death & Decay")
Rage:AddBarOption("Next Death & Decay")

Rage:RegisterEvents(
	"CHAT_MSG_MONSTER_YELL",
	"SPELL_AURA_APPLIED",
	"SPELL_AURA_REMOVED",
	"UNIT_SPELLCAST_CHANNEL_START",
	"SPELL_CAST_START"
);



function Rage:OnEvent(event, arg1)
	if event == "SPELL_AURA_APPLIED" then
		if arg1.spellId == 31249 then
			self:SendSync("Icebolt"..tostring(arg1.destName))
		elseif arg1.spellId == 31258 and arg1.destName == UnitName("player") then
			self:AddSpecialWarning(DBM_RAGE_SPECWARN_DND_YOU);
		elseif arg1.spellId == 66515 then
		self:SendSync("Phase");
		end	
		
	elseif event == "SPELL_AURA_REMOVED" and arg1 then
		if arg1.spellId == 66515 then
			self:Announce(DBM_RAGE_PHASE3_NOW, 1);
			self:StartStatusBarTimer(30, "New Trash", "Interface\\Icons\\Spell_Nature_ElementalShields");
			self:ScheduleSelf(30, "Spawn", "New Trash");
			self:ScheduleSelf(25, "SpawnSoonWarn", "New Trash");
			self:StartStatusBarTimer(45, "New Shark", "Interface\\Icons\\Spell_Nature_ElementalShields");
			self:ScheduleSelf(45, "Spawn", "New Shark");
			self:ScheduleSelf(40, "SpawnSoonWarn", "New Shark");
			self:StartStatusBarTimer(65, "Othil", "Interface\\Icons\\Spell_Nature_ElementalShields");
			self:ScheduleSelf(65, "Spawn", "Othil");
			self:ScheduleSelf(60, "SpawnSoonWarn", "Othil");
			
		end
		
	elseif event == "Spawn" and arg1 then		
		if arg1 == "Othil" then
			self:StartStatusBarTimer(30, "New Trash", "Interface\\Icons\\Spell_Nature_ElementalShields");
			self:ScheduleSelf(30, "Spawn", "New Trash");
			self:ScheduleSelf(25, "SpawnSoonWarn", "New Trash");
			self:StartStatusBarTimer(45, "New Shark", "Interface\\Icons\\Spell_Nature_ElementalShields");
			self:ScheduleSelf(45, "Spawn", "New Shark");
			self:ScheduleSelf(40, "SpawnSoonWarn", "New Shark");
			self:StartStatusBarTimer(65, "Othil", "Interface\\Icons\\Spell_Nature_ElementalShields");
			self:ScheduleSelf(65, "Spawn", "Othil");
			self:ScheduleSelf(60, "SpawnSoonWarn", "Othil");
		end
			
	elseif event == "SpawnSoonWarn" and arg1 then		
		if arg1 == "New Trash" then
			self:Announce(DBM_RAGE_WARN_TRASH_NOW, 1);
		elseif arg1 == "New Shark" then
			self:Announce(DBM_RAGE_WARN_SHARK_NOW, 1);
		elseif arg1 == "Othil" then
			self:Announce(DBM_RAGE_WARN_OTHIL_NOW, 1);
		end
		
	elseif event == "UNIT_SPELLCAST_CHANNEL_START" and type(arg1) == "string" and UnitName(arg1) == DBM_RAGE_NAME then
		if UnitChannelInfo(arg1) == DBM_RAGE_SPELL_DEATH_DECAY then
			self:SendSync("DnD");
		end
	elseif event == "SPELL_CAST_START" then
		if arg1.spellId == 31258 then
			self:SendSync("CastDnD");
		end
	elseif event == "DnDEnd" then
		if self.Options.WarnDnD then
			self:Announce(DBM_RAGE_WARN_DND_END, 1);
		end
		self:StartStatusBarTimer(21, "Next Death & Decay", "Interface\\Icons\\Spell_Shadow_DeathAndDecay");
		self:ScheduleSelf(20, "WarnDnDSoon");
	elseif event == "WarnDnDSoon" then
		if self.Options.WarnDnDSoon then
			self:Announce(DBM_RAGE_WARN_DND_SOON, 1);
		end
	end
end

function Rage:OnSync(msg)
	if msg:sub(0, 7) == "Icebolt" and self.InCombat then
		msg = msg:sub(8);
		if self.Options.WarnIce then
			self:Announce(DBM_RAGE_WARN_ICEBOLT:format(msg), 2);
		end
		if self.Options.IceIcon then
			self:SetIcon(msg, 4);
		end
	elseif msg == "DnD" then
		self:StartStatusBarTimer(15, "Death & Decay", "Interface\\Icons\\Spell_Shadow_DeathAndDecay");
		self:ScheduleSelf(15, "DnDEnd");
		self:SendSync("CastDnD");
	elseif msg == "CastDnD" then
		if self.Options.WarnDnD then
			self:Announce(DBM_RAGE_WARN_DND, 3);
		end
	elseif msg == "Phase" then
		self:Announce(DBM_RAGE_PHASE2_NOW, 1);
	end
end

function Rage:OnCombatEnd()
		self:UnScheduleSelf("Spawn", "New Trash");
		self:UnScheduleSelf("Spawn", "New Shark");
		self:UnScheduleSelf("Spawn", "Othil");
		self:UnScheduleSelf("SpawnSoonWarn", "New Trash");
		self:UnScheduleSelf("SpawnSoonWarn", "New Shark");
		self:UnScheduleSelf("SpawnSoonWarn", "Othil");
		self:EndStatusBarTimer("New Trash");
		self:EndStatusBarTimer("New Shark");
		self:EndStatusBarTimer("Othil");
end