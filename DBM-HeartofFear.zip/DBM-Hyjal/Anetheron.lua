local Anetheron = DBM:NewBossMod("Anetheron", DBM_ANETHERON_NAME, DBM_ANETHERON_DESCRIPTION, DBM_MOUNT_HYJAL, DBM_HYJAL_TAB, 2);

Anetheron.Version	= "1.0";
Anetheron.Author	= "Copperfield";

Anetheron:SetCreatureID(17808)
Anetheron:RegisterCombat("yell", DBM_ANETHERON_YELL_PULL)
Anetheron:SetMinCombatTime(60)

Anetheron:RegisterEvents(
	"SPELL_AURA_APPLIED",
	"SPELL_CAST_START",
	"SPELL_CAST_SUCCESS"
);

function Anetheron:OnEvent(event, arg1)
	if event == "SPELL_AURA_APPLIED" then
		if arg1.spellId == 31306 then
			self:SendSync("CarrionSwarm");
		elseif arg1.spellId == 18173  then
			self:SendSync("Metka"..tostring(arg1.destName));
		end
	elseif event == "SPELL_CAST_START" then
		if arg1.spellId == 31299 then
			self:SendSync("CastInferno");
		end
	elseif event == "CheckTarget" then
		local target
		for i = 1, GetNumRaidMembers() do
			if UnitName("raid"..i.."target") == DBM_ANETHERON_NAME then
				target = UnitName( "raid"..i.."targettarget")
				break
			end
		end
		if target then
			
				self:Announce(DBM_ANETHERON_INFERNO:format(target), 1)
				self:SetIcon(target, 5)
			if target == UnitName("player") then
				
					SendChatMessage(DBM_ANETHERON_INFERNO)
					self:AddSpecialWarning(DBM_ANETHERON_INFERNO)
				
			end
		end
	end
end


function Anetheron:OnSync(msg)
	if msg == "CarrionSwarm" then
		self:Announce(DBM_ANETHERON_WARN_CARRION, 1);
	elseif msg == "CastInferno" then
		self:ScheduleSelf(0.2, "CheckTarget")
	elseif string.sub(msg, 1, 5) == "Metka" then
		local target = string.sub(msg, 6);
		if target then
				self:SetIcon(target, 6);
		end	
	end
end
