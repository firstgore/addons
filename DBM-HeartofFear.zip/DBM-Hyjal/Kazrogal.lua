local Kazrogal = DBM:NewBossMod("Kazrogal", DBM_KAZROGAL_NAME, DBM_KAZROGAL_DESCRIPTION, DBM_MOUNT_HYJAL, DBM_HYJAL_TAB, 3);

Kazrogal.Version	= "1.0";
Kazrogal.Author		= "Copperfield";

local counter = 0;

Kazrogal:SetCreatureID(17888)
Kazrogal:RegisterCombat("yell", DBM_KAZROGAL_YELL_PULL)
Kazrogal:SetMinCombatTime(80)

Kazrogal:RegisterEvents(
	"SPELL_AURA_APPLIED"
);


function Kazrogal:OnCombatStart()
	counter = 0;
	self:StartStatusBarTimer(25, "Metka-1-ya", "Interface\\Icons\\INV_Misc_Fish_13");
end

function Kazrogal:OnEvent(event, args)
	if event == "SPELL_AURA_APPLIED" then
		if args.spellId == 31447 then
			self:SendSync("Debuff")
		end	
	end
end




function Kazrogal:OnEvent(event, arg1)
	if event == "SPELL_AURA_APPLIED" then
		if arg1.spellId == 301021 then
			self:SendSync("Metka"..tostring(arg1.destName))
		end	
	end
end




function Kazrogal:OnSync(msg)
	if string.sub(msg, 1, 5) == "Metka" then
		local target = string.sub(msg, 6);
		if target then
			
				self:SetIcon(target, 6);
				self:SendHiddenWhisper(DBM_KAZROGAL_WARN_METKA, target)
			
		end
	self:EndStatusBarTimer("Metka-1-ya");
	elseif msg == "Debuff" then
		counter = counter + 1;
		self:Announce(DBM_KAZROGAL_WARN_MARK:format(counter), 2); -- timer?
	end
end